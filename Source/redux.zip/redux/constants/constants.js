export const API = "API";
export const ON_LOG_USER="ON_LOG_USER";
export const ON_REG_USER="ON_REG_USER";




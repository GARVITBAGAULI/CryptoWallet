export const APP_VERSION = "1.0";
export const BASE_URL = "https://chryus-api.blockcoders.co/api/v1/"; 
export const LOGIN_URL="auth/login";
export const REGISTER_URL ="auth/register";



